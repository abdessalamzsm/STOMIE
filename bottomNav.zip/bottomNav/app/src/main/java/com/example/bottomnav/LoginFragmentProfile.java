package com.example.bottomnav;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.dd.processbutton.iml.ActionProcessButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;

import java.util.HashMap;
import java.util.Map;


public class LoginFragmentProfile extends Fragment {
    EditText email_login,email_register,name_register;
    EditText password_login,password_register;
    ActionProcessButton Button_login,Button_register;

    BottomNavigationView nav;
    @Nullable

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login_profile, container, false);
        email_login = view.findViewById(R.id.login_email_text);
        password_login = view.findViewById(R.id.login_password_text);


        email_register = view.findViewById(R.id.register_email_text);
        password_register = view.findViewById(R.id.register_password_text);
        name_register = view.findViewById(R.id.register_name_text);


        Button_login = view.findViewById(R.id.login_button);
        Button_register = view.findViewById(R.id.register_button);

        nav = view.findViewById(R.id.Bottom_nav);

        Button_login.setProgress(0);
        Button_login.setMode(ActionProcessButton.Mode.ENDLESS);
        Button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button_login.setClickable(false);

                email_login.clearFocus();
                password_login.clearFocus();
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(password_login.getWindowToken(), 0);
                if(email_login.getText().length() == 0 || password_login.getText().length() == 0)
                {
                    Toast.makeText(getActivity(), "Fields cannot be empty.", Toast.LENGTH_SHORT).show();

                    Button_login.setProgress(-1);
                    Button_login.setClickable(true);
                }
                else {
                    Button_login.setProgress(1);
                    FirebaseAuth.getInstance().signInWithEmailAndPassword(email_login.getText().toString(), password_login.getText().toString())
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if(task.isSuccessful()) {
                                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                        if(user.isEmailVerified()) {
                                            Toast.makeText(getActivity(), "Login Complete", Toast.LENGTH_SHORT).show();
                                            onStart();
                                        }
                                        else
                                        {
                                            Toast.makeText(getActivity(),"Please verify your accoune !",Toast.LENGTH_LONG).show();
                                            Button_login.setProgress(-1);
                                            Button_login.setClickable(true);
                                        }
                                    }
                                }
                            });
                }
            }
        });
        Button_register.setProgress(0);
        Button_register.setMode(ActionProcessButton.Mode.ENDLESS);
        Button_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button_register.setClickable(false);

                Button_login.setClickable(false);
                name_register.clearFocus();
                email_register.clearFocus();
                password_register.clearFocus();


                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(Button_register.getWindowToken(), 0);
                if(email_register.getText().toString().length() == 0 || password_register.getText().toString().length() == 0)
                {
                    Toast.makeText(getActivity(), "Fields cannot be empty.", Toast.LENGTH_SHORT).show();

                    Button_register.setProgress(-1);
                    Button_register.setClickable(true);

                    Button_login.setClickable(true);
                }
                else
                {
                    Button_register.setProgress(1);

                    // Registering user with data he gave us

                    FirebaseAuth.getInstance().createUserWithEmailAndPassword(email_register.getText().toString(), password_register.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>()
                    {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task)
                        {
                            if(task.isSuccessful())
                            {
                                FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

                                if(firebaseUser != null)
                                {
                                    String userid = firebaseUser.getUid();

                                    // "Packing" user data

                                    Map map = new HashMap<>();
                                    //map.put("token", FirebaseInstanceId.getInstance().getToken());
                                    map.put("name", name_register.getText().toString());
                                    map.put("email", email_register.getText().toString());
                                    map.put("status", "Welcome to my Profile!");
                                    map.put("image", "default");
                                    map.put("cover", "default");
                                    map.put("date", ServerValue.TIMESTAMP);

                                    // Uploading user data

                                    FirebaseDatabase.getInstance().getReference().child("Users").child("Pation").child(userid).setValue(map).addOnCompleteListener(new OnCompleteListener<Void>()
                                    {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task)
                                        {
                                            if(task.isSuccessful())
                                            {
                                                Button_register.setProgress(100);

                                                FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification();
                                                Toast.makeText(getActivity(), "We have sent you a verification email to activate your account.", Toast.LENGTH_LONG).show();
                                                FirebaseAuth.getInstance().signOut();

                                                Button_login.setClickable(true);
                                            }
                                            else
                                            {
                                                Log.d("Field", "registerData failed: " + task.getException().getMessage());
                                            }
                                        }
                                    });
                                }
                            }
                            else
                            {
                                Toast.makeText(getActivity(), task.getException().getMessage(), Toast.LENGTH_LONG).show();

                                Log.d("field", "createUser failed: " + task.getException().getMessage());

                                Button_register.setProgress(-1);
                                Button_register.setClickable(true);

                                Button_login.setClickable(true);
                            }
                        }
                    });
                }
            }
        });
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        if(FirebaseAuth.getInstance().getCurrentUser() != null)
        {
            FragmentManager frman = getFragmentManager();
            FragmentTransaction ftran = frman.beginTransaction();
            Fragment ffrag = new ProfileFragment();
            ftran.replace(R.id.fragment_container, ffrag);
            ftran.commit();
        }
}

}

