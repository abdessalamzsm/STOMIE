package com.example.bottomnav;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.dd.processbutton.iml.ActionProcessButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

import static android.app.Activity.RESULT_OK;


public class LoginFragmentProfile extends Fragment {
    EditText email_login,email_register,name_register;
    EditText password_login,password_register;
    ActionProcessButton Button_login,Button_register;
    ImageView image;
    Uri pickedImgUri;

    String imageUrl;
    static int PReqCode = 1 ;
    static int REQUESCODE = 1 ;


    BottomNavigationView nav;
    @Nullable

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login_profile, container, false);
        email_login = view.findViewById(R.id.login_email_text);
        password_login = view.findViewById(R.id.login_password_text);


        email_register = view.findViewById(R.id.register_email_text);
        password_register = view.findViewById(R.id.register_password_text);
        name_register = view.findViewById(R.id.register_name_text);


        Button_login = view.findViewById(R.id.login_button);
        Button_register = view.findViewById(R.id.register_button);


        image = view.findViewById(R.id.regUserPhoto);

        nav = view.findViewById(R.id.Bottom_nav);

        Button_login.setProgress(0);
        Button_login.setMode(ActionProcessButton.Mode.ENDLESS);
        Button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button_login.setClickable(false);

                email_login.clearFocus();
                password_login.clearFocus();
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(password_login.getWindowToken(), 0);
                if(email_login.getText().length() == 0 || password_login.getText().length() == 0)
                {
                    Toast.makeText(getActivity(), "Fields cannot be empty.", Toast.LENGTH_SHORT).show();

                    Button_login.setProgress(-1);
                    Button_login.setClickable(true);
                }
                else {
                    Button_login.setProgress(1);
                    FirebaseAuth.getInstance().signInWithEmailAndPassword(email_login.getText().toString(), password_login.getText().toString())
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if(task.isSuccessful()) {
                                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                        if(user.isEmailVerified()) {
                                            Toast.makeText(getActivity(), "Login Complete", Toast.LENGTH_SHORT).show();
                                            onStart();
                                        }
                                        else
                                        {
                                            Toast.makeText(getActivity(),"Please verify your accoune !",Toast.LENGTH_LONG).show();
                                            Button_login.setProgress(-1);
                                            Button_login.setClickable(true);
                                        }
                                    }
                                }
                            });
                }
            }
        });


        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Build.VERSION.SDK_INT >= 22) {

                    checkAndRequestForPermission();


                }
                else
                {
                    openGallery();
                }

            }
        });
        Button_register.setProgress(0);
        Button_register.setMode(ActionProcessButton.Mode.ENDLESS);
        Button_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button_register.setClickable(false);

                Button_login.setClickable(false);
                name_register.clearFocus();
                email_register.clearFocus();
                password_register.clearFocus();


                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(Button_register.getWindowToken(), 0);
                if(email_register.getText().toString().length() == 0 || password_register.getText().toString().length() == 0)
                {
                    Toast.makeText(getActivity(), "Fields cannot be empty.", Toast.LENGTH_SHORT).show();

                    Button_register.setProgress(-1);
                    Button_register.setClickable(true);

                    Button_login.setClickable(true);
                }
                else
                {
                    Button_register.setProgress(1);

                    // Registering user with data he gave us

                    FirebaseAuth.getInstance().createUserWithEmailAndPassword(email_register.getText().toString(), password_register.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>()
                    {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task)
                        {
                            if(task.isSuccessful())
                            {

                                FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                                updateUserInfo( name_register.getText().toString() ,pickedImgUri,firebaseUser);

                                if(firebaseUser != null)
                                {
                                    final String userid = firebaseUser.getUid();

                                    // "Packing" user data

                                    Map map = new HashMap<>();
                                    //map.put("token", FirebaseInstanceId.getInstance().getToken());
                                    map.put("name", name_register.getText().toString());
                                    map.put("email", email_register.getText().toString());
                                    map.put("status", "Welcome to my Profile!");
                                    //map.put("image",imageUrl);
                                    map.put("cover", "default");
                                    map.put("date", ServerValue.TIMESTAMP);
                                    //Log.d("photo",imageUrl);
                                    // Uploading user data

                                    FirebaseDatabase.getInstance().getReference().child("Users").child("Pation").child(userid).setValue(map).addOnCompleteListener(new OnCompleteListener<Void>()
                                    {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task)
                                        {
                                            if(task.isSuccessful())
                                            {
                                                Button_register.setProgress(100);

                                                FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification();
                                                Toast.makeText(getActivity(), "We have sent you a verification email to activate your account.", Toast.LENGTH_LONG).show();

                                                FirebaseAuth.getInstance().signOut();
                                                Button_login.setClickable(true);


                                                send(userid);




                                            }
                                            else
                                            {
                                                Log.d("Field", "registerData failed: " + task.getException().getMessage());
                                            }
                                        }
                                    });
                                }
                            }
                            else
                            {
                                Toast.makeText(getActivity(), task.getException().getMessage(), Toast.LENGTH_LONG).show();

                                Log.d("field", "createUser failed: " + task.getException().getMessage());

                                Button_register.setProgress(-1);
                                Button_register.setClickable(true);

                                Button_login.setClickable(true);
                            }
                        }
                    });
                }
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        if(FirebaseAuth.getInstance().getCurrentUser() != null)
        {
            FragmentManager frman = getFragmentManager();
            FragmentTransaction ftran = frman.beginTransaction();
            Fragment ffrag = new ProfileFragment();
            ftran.replace(R.id.fragment_container, ffrag);
            ftran.commit();
        }
    }

    private void send(final String userid)
    {
        final FirebaseDatabase data = FirebaseDatabase.getInstance();
        DatabaseReference myref = data.getReference("Users");
        myref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                DataSnapshot ds = dataSnapshot.child("Specialiste");
                for (DataSnapshot ds1 : ds.getChildren()) {
                    final String otherUserId = ds1.getKey();
                    FirebaseDatabase.getInstance().getReference("Chat").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            DataSnapshot ds2 = dataSnapshot.child(userid);
                            DataSnapshot ds3 = ds2.child(otherUserId);
                            if (ds3.child("message").getValue(String.class) == null) {
                                String message = "Welcome To STOMIE APP";
                                // Pushing message/notification so we can get keyIds

                                DatabaseReference userMessage = FirebaseDatabase.getInstance().getReference().child("Messages").child(userid).child(otherUserId).push();
                                String pushId = userMessage.getKey();

                                DatabaseReference notificationRef = FirebaseDatabase.getInstance().getReference().child("Notifications").child(otherUserId).push();
                                String notificationId = notificationRef.getKey();

                                // "Packing" message

                                Map messageMap = new HashMap();
                                messageMap.put("message", message);
                                messageMap.put("type", "text");
                                messageMap.put("from", otherUserId);
                                messageMap.put("to", userid);
                                messageMap.put("timestamp", ServerValue.TIMESTAMP);

                                HashMap<String, String> notificationData = new HashMap<>();
                                notificationData.put("from", userid);
                                notificationData.put("type", "message");

                                Map userMap = new HashMap();
                                userMap.put("Messages/" + userid + "/" + otherUserId + "/" + pushId, messageMap);
                                userMap.put("Messages/" + otherUserId + "/" + userid + "/" + pushId, messageMap);

                                userMap.put("Chat/" + userid + "/" + otherUserId + "/message", message);
                                userMap.put("Chat/" + userid + "/" + otherUserId + "/timestamp", ServerValue.TIMESTAMP);
                                userMap.put("Chat/" + userid + "/" + otherUserId + "/seen", ServerValue.TIMESTAMP);

                                userMap.put("Chat/" + otherUserId + "/" + userid + "/message", message);
                                userMap.put("Chat/" + otherUserId + "/" + userid + "/timestamp", ServerValue.TIMESTAMP);
                                userMap.put("Chat/" + otherUserId + "/" + userid + "/seen", 0);

                                userMap.put("Notifications/" + otherUserId + "/" + notificationId, notificationData);

                                FirebaseDatabase.getInstance().getReference().updateChildren(userMap, new DatabaseReference.CompletionListener() {
                                    @Override
                                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {

                                        if (databaseError != null) {
                                            Log.d("testUpdate", "sendMessage(): updateChildren failed: " + databaseError.getMessage());
                                        }
                                    }
                                });
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    private void checkAndRequestForPermission() {


        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE)) {

                Toast.makeText(getActivity(),"Please accept for required permission",Toast.LENGTH_SHORT).show();

            }

            else
            {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PReqCode);
            }

        }
        else
            openGallery();

    }

    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,REQUESCODE);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == REQUESCODE && data != null ) {

            // the user has successfully picked an image
            // we need to save its reference to a Uri variable
            pickedImgUri = data.getData() ;
            image.setImageURI(pickedImgUri);


        }


    }

    private void updateUserInfo(final String name, final Uri pickedImgUri, final FirebaseUser currentUser) {

        // first we need to upload user photo to firebase storage and get url

        StorageReference mStorage = FirebaseStorage.getInstance().getReference().child("profile_images").child(currentUser + ".jpg");
        final StorageReference imageFilePath = mStorage.child(pickedImgUri.getLastPathSegment());
        imageFilePath.putFile(pickedImgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                // image uploaded succesfully
                // now we can get our image url

                imageFilePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        imageUrl = uri.toString();
                        Log.d("photo",""+imageUrl);
                        // uri contain user image url
                        FirebaseDatabase.getInstance().getReference().child("Users").child("Pation").child(currentUser.getUid()).child("image").setValue(imageUrl)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        Log.d("photo","okokokok");
                                    }
                                });

                        UserProfileChangeRequest profleUpdate = new UserProfileChangeRequest.Builder()
                                .setDisplayName(name)
                                .setPhotoUri(uri)
                                .build();

                        currentUser.updateProfile(profleUpdate)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {

                                        if (task.isSuccessful()) {
                                            // user info updated successfully
                                        }

                                    }
                                });

                    }
                });





            }
        });






    }

}

