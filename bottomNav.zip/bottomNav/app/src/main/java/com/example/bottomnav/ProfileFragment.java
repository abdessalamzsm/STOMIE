package com.example.bottomnav;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.flaviofaria.kenburnsview.KenBurnsView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;
import jahirfiquitiva.libs.fabsmenu.FABsMenu;
import jahirfiquitiva.libs.fabsmenu.TitleFAB;

import static android.app.Activity.RESULT_OK;


public class ProfileFragment extends Fragment {
    private FABsMenu menu;
    private TitleFAB button1, button2, button3,button4,button5;

    private DatabaseReference userDatabase, requestsDatabase, friendsDatabase;
    private ValueEventListener userListener, requestsListener, friendsListerner;

    private String currentUserId,otherUserId;
    private TextView name, status;
    private CircleImageView image;
    private KenBurnsView cover;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile,container,false);
        name = view.findViewById(R.id.profile_name);
        status = view.findViewById(R.id.profile_status);
        image = view.findViewById(R.id.profile_image);
        menu = view.findViewById(R.id.profile_fabs_menu);
        cover = view.findViewById(R.id.profile_cover);

        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        initMyProfile();
        return view;
    }

    public void onStart()
    {
        super.onStart();

        if(userDatabase != null && userListener != null)
        {
            userDatabase.removeEventListener(userListener);
        }

        // Initialize/Update realtime user data such as name, email, status, image

        userDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Pation").child(currentUserId);
        userDatabase.keepSynced(true); // For offline use
                                    userListener = new ValueEventListener()
                                {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot)
                                    {
                                        try
                                        {
                                            String layoutName = dataSnapshot.child("name").getValue().toString();
                                            String layoutStatus = dataSnapshot.child("status").getValue().toString();
                                            final String layoutImage = dataSnapshot.child("image").getValue().toString();
                                            final String layoutCover = dataSnapshot.child("cover").getValue().toString();

                                            name.setText(layoutName);
                                            status.setText("\"" + layoutStatus + "\"");

                                            if(!layoutImage.equals("default"))
                                            {
                                                Picasso.get()
                                                        .load(layoutImage)
                                                        .resize((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 180, getResources().getDisplayMetrics()), (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 180, getResources().getDisplayMetrics()))
                                                        .centerCrop()
                                                        .networkPolicy(NetworkPolicy.OFFLINE)
                                                        .placeholder(R.drawable.user)
                                                        .error(R.drawable.user)
                                                        .into(image, new Callback()
                                                        {
                                                            @Override
                                                            public void onSuccess()
                                                            {

                                                            }

                                                            @Override
                                                            public void onError(Exception e) {
                                                                Picasso.get()
                                                                        .load(layoutImage)
                                                                        .resize((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 180, getResources().getDisplayMetrics()), (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 180, getResources().getDisplayMetrics()))
                                                                        .centerCrop()
                                                                        .placeholder(R.drawable.user)
                                                                        .error(R.drawable.user)
                                                                        .into(image);
                                                            }

                                                        });

                                                image.setOnClickListener(new View.OnClickListener()
                                                {
                                                    @Override
                                                    public void onClick(View view)
                                                    {
                                                        Intent intent = new Intent(getActivity(), FullScreenActivity.class);
                                                        intent.putExtra("imageUrl", layoutImage);
                                                        startActivity(intent);
                                                    }
                                                });
                                            }
                                            else
                                            {
                                                image.setImageResource(R.drawable.user);
                                            }

                                            if(!layoutCover.equals("default"))
                                            {
                                                Picasso.get()
                                                        .load(layoutCover)
                                                        .resize(getResources().getDisplayMetrics().widthPixels, (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 260, getResources().getDisplayMetrics()))
                                                        .centerCrop()
                                                        .networkPolicy(NetworkPolicy.OFFLINE)
                                                        .placeholder(R.drawable.logo_cover)
                                                        .error(R.drawable.logo_cover)
                                                        .into(cover, new Callback()
                                                        {
                                                            @Override
                                                            public void onSuccess()
                                                            {

                                                            }

                                                            @Override
                                                            public void onError(Exception e) {

                                                                Picasso.get()
                                                                        .load(layoutCover)
                                                                        .resize(getResources().getDisplayMetrics().widthPixels, (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 260, getResources().getDisplayMetrics()))
                                                                        .centerCrop()
                                                                        .placeholder(R.drawable.logo_cover)
                                                                        .error(R.drawable.logo_cover)
                                                                        .into(cover);
                                                            }

                                });
                    }
                    else
                    {
                        cover.setImageResource(R.drawable.logo_cover);
                    }
                }
                catch(Exception e)
                {
                    Log.d("imageErreur", "userDatabase listener exception: " + e.getMessage());
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
                Log.d("imageErreur", "userDatabase listener failed: " + databaseError.getMessage());
            }
        };
        userDatabase.addValueEventListener(userListener);


            initMyProfile();

    }

    @Override
    public void onResume()
    {
        super.onResume();

        FirebaseDatabase.getInstance().getReference().child("Users").child("Pation").child(currentUserId).child("online").setValue("true");
    }

    @Override
    public void onPause()
    {
        super.onPause();

        FirebaseDatabase.getInstance().getReference().child("Users").child("Pation").child(currentUserId).child("online").setValue(ServerValue.TIMESTAMP);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, final Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1 && resultCode == RESULT_OK)
        {
            Uri url = data.getData();

            //Uploading selected picture

            StorageReference file = FirebaseStorage.getInstance().getReference().child("profile_images").child(currentUserId + ".jpg");
            file.putFile(url).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    taskSnapshot.getStorage().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            String imageUrl = uri.toString();

                            // Updating image on user data

                            userDatabase.child("image").setValue(imageUrl).addOnCompleteListener(new OnCompleteListener<Void>()
                            {
                                @Override
                                public void onComplete(@NonNull Task<Void> task)
                                {
                                    if(task.isSuccessful())
                                    {
                                        Toast.makeText(getActivity(), "Picture updated", Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        Log.d("ImageErreur", "updateImage listener failed: " + task.getException().getMessage());
                                    }
                                }
                            });
                        }
                    });
         }
            });
        }
        else if(requestCode == 2 && resultCode == RESULT_OK)
        {
            Uri url = data.getData();

            //Uploading selected cover picture

            StorageReference file = FirebaseStorage.getInstance().getReference().child("profile_covers").child(currentUserId + ".jpg");
            file.putFile(url).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    taskSnapshot.getStorage().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            String imageUrl = uri.toString();
                            userDatabase.child("cover").setValue(imageUrl).addOnCompleteListener(new OnCompleteListener<Void>()
                            {
                                @Override
                                public void onComplete(@NonNull Task<Void> task)
                                {
                                    if(task.isSuccessful())
                                    {
                                        Toast.makeText(getActivity(), "Cover updated", Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        Log.d("ImageErreur", "updateUserCover listener failed: " + task.getException().getMessage());
                                    }
                                }
                            });
                        }
                    });
                }
            });
        }
    }
    @SuppressLint({"WrongConstant", "ResourceAsColor"})
    public void initMyProfile()
    {
        if(button1 != null)
        {
            menu.removeButton(button1);
        }

        if(button2 != null)
        {
            menu.removeButton(button2);
        }

        if(button3 != null)
        {
            menu.removeButton(button3);
        }

        if(button4 != null)
        {
            menu.removeButton(button4);
        }

        if(button5 != null)
        {
            menu.removeButton(button5);
        }

        button1 = new TitleFAB(getActivity());
        button1.setTitle("Change Cover");
        button1.setBackgroundColor(getResources().getColor(R.color.colorPurple));
        button1.setRippleColor(getResources().getColor(R.color.colorPurpleDark));
        button1.setImageResource(R.drawable.ic_filter_hdr_white_24dp);

        button1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent gallery = new Intent();
                gallery.setType("image/*");
                gallery.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(gallery, "Select Cover"), 2);

                menu.collapse();
            }
        });
        menu.addButton(button1);
        button1.setSize(FloatingActionButton.SIZE_MINI);


        button2 = new TitleFAB(getActivity());
        button2.setTitle("Change Image");
        button2.setBackgroundColor(getResources().getColor(R.color.colorGreen));
        button2.setRippleColor(getResources().getColor(R.color.colorGreenDark));
        button2.setImageResource(R.drawable.ic_image_white_24dp);
        button2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent gallery = new Intent();
                gallery.setType("image/*");
                gallery.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(gallery, "Select Image"), 1);

                menu.collapse();
            }
        });
        menu.addButton(button2);
        button2.setSize(FloatingActionButton.SIZE_MINI);

        button3 = new TitleFAB(getActivity());
        button3.setTitle("Change Status");
        button3.setBackgroundColor(getResources().getColor(R.color.colorBlue));
        button3.setRippleColor(getResources().getColor(R.color.colorBlueDark));
        button3.setImageResource(R.drawable.ic_edit_white_24dp);
        button3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                menu.collapse();

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Enter your new Status:");

                View mView = ProfileFragment.this.getLayoutInflater().inflate(R.layout.status_dialog, null);

                final EditText tmp = mView.findViewById(R.id.status_text);

                builder.setPositiveButton("Update", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        final String newStatus = tmp.getText().toString();

                        if(newStatus.length() < 1 || newStatus.length() > 24)
                        {
                            Toast.makeText(getActivity(), "Status must be between 1-24 characters.", Toast.LENGTH_LONG).show();
                            dialogInterface.dismiss();
                        }
                        else
                        {
                            // Updating on status on user data

                            userDatabase.child("status").setValue(newStatus).addOnCompleteListener(new OnCompleteListener<Void>()
                            {
                                @Override
                                public void onComplete(@NonNull Task<Void> task)
                                {
                                    if(task.isSuccessful())
                                    {
                                        Toast.makeText(getActivity(), "Status updated", Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        Toast.makeText(getActivity(), task.getException().getMessage(), Toast.LENGTH_LONG).show();

                                    }
                                }
                            });
                        }
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        dialogInterface.dismiss();
                    }
                });

                builder.setView(mView);
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        menu.addButton(button3);
        button3.setSize(FloatingActionButton.SIZE_MINI);

        button4 = new TitleFAB(getActivity());
        button4.setTitle("Change Name");
        button4.setBackgroundColor(getResources().getColor(R.color.nameColor));
        button4.setRippleColor(getResources().getColor(R.color.nameColor2));
        button4.setImageResource(R.drawable.ic_edit_white_24dp);
        button4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                menu.collapse();

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Enter your new Name :");

                View mView = ProfileFragment.this.getLayoutInflater().inflate(R.layout.status_dialog, null);

                final EditText tmp = mView.findViewById(R.id.status_text);
                tmp.setHint("New Name ");
                builder.setPositiveButton("Update", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        final String newStatus = tmp.getText().toString();

                        if(newStatus.length() < 1 || newStatus.length() > 24)
                        {
                            Toast.makeText(getActivity(), "Name must be between 1-15 characters.", Toast.LENGTH_LONG).show();
                            dialogInterface.dismiss();
                        }
                        else
                        {
                            // Updating on status on user data

                            userDatabase.child("name").setValue(newStatus).addOnCompleteListener(new OnCompleteListener<Void>()
                            {
                                @Override
                                public void onComplete(@NonNull Task<Void> task)
                                {
                                    if(task.isSuccessful())
                                    {
                                        Toast.makeText(getActivity(), "Name updated", Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        Toast.makeText(getActivity(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        }
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        dialogInterface.dismiss();
                    }
                });

                builder.setView(mView);
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        button4.setSize(FloatingActionButton.SIZE_MINI);
        menu.addButton(button4);


        button5 = new TitleFAB(getActivity());
        button5.setTitle("Disconnected");
        button5.setBackgroundColor(getResources().getColor(R.color.holo_red_light));
        button5.setRippleColor(getResources().getColor(R.color.colorPurpleDark));
        button5.setImageResource(R.drawable.ic_signs);

        button5.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                FirebaseAuth.getInstance().signOut();
                FragmentManager frman = getFragmentManager();
                FragmentTransaction ftran = frman.beginTransaction();
                Fragment ffrag = new LoginFragmentProfile();
                ftran.replace(R.id.fragment_container, ffrag);
                ftran.commit();
                menu.collapse();
            }
        });
        menu.addButton(button5);

        button5.setSize(FloatingActionButton.SIZE_MINI);



    }
}
