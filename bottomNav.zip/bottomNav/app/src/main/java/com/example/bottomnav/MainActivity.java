package com.example.bottomnav;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView Bottom_nav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Bottom_nav = findViewById(R.id.Bottom_nav);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
        if(getIntent().getStringExtra("fragment") != null)
        {
            Toast.makeText(getApplicationContext(),"hello test"+getIntent().getStringExtra("fragment"),Toast.LENGTH_LONG).show();
            Fragment fragment = null;
            switch (getIntent().getStringExtra("fragment")) {
                case "chat":
                    fragment = new ChatFragment();
                    Bottom_nav.setSelectedItemId(R.id.Chat);
                    break;
                case "Forum":
                    fragment = new ForumFragment();
                    Bottom_nav.setSelectedItemId(R.id.Forum);
                    break;
                case "profile":
                    fragment = new ProfileFragment();
                    Bottom_nav.setSelectedItemId(R.id.Profile);
                    break;

            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
        }
        Bottom_nav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                Fragment fragment = null;
                switch (menuItem.getItemId()) {
                    case R.id.Home:
                        fragment = new HomeFragment();
                        break;
                    case R.id.Forum:
                        fragment = new LoginFragmentForum();
                        break;
                    case R.id.Chat:
                        fragment = new LoginFragmentChat();
                        break;
                    case R.id.Profile:
                        fragment = new LoginFragmentProfile();
                        break;

                }
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
                return true;
            }
        });
    }

}
